<?php

namespace App\Http\Controllers;

use App\Models\About;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class AboutPageController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     *      * @return Application|Factory|View
     */
    public function index()
    {
        $about = About::first();
        return view('pages.about', compact('about'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return RedirectResponse
     * @throws ValidationException
     */
    public function update(Request $request)
    {
        $this->validate($request, [
            'body' => 'required|string',
            'sub_body' => 'required|string',
        ]);

        $about = About::first();
        $about->body = $request->body;
        $about->sub_body = $request->sub_body;


        if($request->file('display_img')){
            $img_file = $request->file('display_img');
            $img_file->storeAs('public/img/','display_img.' . $img_file->getClientOriginalExtension());
            $about->display_img = "storage/img/display_img." . $img_file->getClientOriginalExtension();

        }


        $about->save();



        return redirect()->route('admin.about')->with('success', "About Page data has been updated successfully");
    }

}
