<?php

namespace App\Http\Controllers;

use App\Models\Main;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class MainPagesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function dashboard(){
        return view('pages.dashboard');
    }

    /**
     * Display a listing of the resource.
     *
     * @return Application|Factory|View
     */
    public function index()
    {
        $main = Main::first();
        return view('pages.main', compact('main'));
    }

//    public function edit($id)
//    {
//        $editMain = Main::find($id);
//
//        return view('pages.editmain', compact('editMain'));
//    }


    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return RedirectResponse
     * @throws ValidationException
     */
    public function update(Request $request)
    {
        $this->validate($request, [
            'typography' => 'required|string',
            'sub_title' => 'required|string',
        ]);

        $main = Main::first();
        $main->typography = $request->typography;
        $main->sub_title = $request->sub_title;




        if($request->file('background_img')){
            $img_file = $request->file('background_img');
            $img_file->storeAs('public/img/','background_img.' . $img_file->getClientOriginalExtension());
            $main->background_img = "storage/img/background_img." . $img_file->getClientOriginalExtension();

        }

        if($request->file('resume')){
            $pdf_file = $request->file('resume');
            $pdf_file->storeAs('public/pdf/','resume.' . $pdf_file->getClientOriginalExtension());
            $main->resume = "storage/pdf/resume." . $pdf_file->getClientOriginalExtension();

        }

        $main->save();



        return redirect()->route('admin.main')->with('success', "Main Page data has been updated successfully");
    }

}
