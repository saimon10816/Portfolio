<?php


namespace App\Http\Services;


abstract class BaseService extends ResponseService {
    public $repository;
}
