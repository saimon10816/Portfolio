<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Main</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Main</li>
            </ol>
            <div id="layoutSidenav_content">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-50">
                            <div class="card">
                                <div class="card-header"><?php echo e(__('Edit Contents')); ?></div>

                                <div class="card-body">
                                    <form action="<?php echo e(route('admin.main.update')); ?>" method="POST"
                                          enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo e(method_field('PUT')); ?>

                                        <div class="row">
                                            <div class="form-group col-md-10 mt-10">
                                                <div class="mb-4">
                                                <h3>Background Image</h3>
                                                <img src="<?php echo e(url($main->background_img)); ?>"
                                                     class="img-thumbnail">
                                                <input class="mt-2" type="file" id="background_img"
                                                       name="background_img">
                                                </div>
                                                <div class="mb-7">
                                                    <label for="typography"><h4>Typography</h4></label>
                                                    <input type="text" class="form-control" id="typography"
                                                           name="typography"
                                                           value="<?php echo e($main->typography); ?>">
                                                </div>
                                                <div class="mb-4">
                                                    <label for="sub_title"><h4>Sub Title</h4></label>
                                                    <input type="text" class="form-control" id="sub_title"
                                                           name="sub_title"
                                                           value="<?php echo e($main->sub_title); ?>">
                                                </div>
                                                <div class="mb-4">
                                                    <h4>Upload Resume</h4>
                                                    <input class="mt-2" type="file" id="resume" name="resume">
                                                </div>
                                                <div class="col-3">
                                                    <input type="submit" name="submit" class="btn btn-outline-primary primary btn-block btn-rounded mt3">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Portfolio-app\resources\views/pages/main.blade.php ENDPATH**/ ?>