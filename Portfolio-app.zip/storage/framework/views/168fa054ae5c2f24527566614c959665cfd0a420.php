<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">List of Media</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">List of Media</li>
            </ol>
            <div id="layoutSidenav_content">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-50">
                            <div class="card">
                                <div class="card-header"><?php echo e(__('Edit Contents')); ?></div>

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table align-middle">
                                            <thead>
                                            <tr>
                                                <th scope="col">Id</th>
                                                <th scope="col">Media Image</th>
                                                <th scope="col">Media Title</th>
                                                <th scope="col">Media By</th>
                                                <th scope="col">Created At</th>
                                                <th scope="col">Media Body</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php if(count($mediaLists) > 0): ?>
                                                <?php $__currentLoopData = $mediaLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mediaList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($mediaList->id); ?></th>
                                                        <td>
                                                            <div class="form-group col-md-3 mt-3">
                                                                <div class="mb-4">
                                                                    <img src="<?php echo e(url($mediaList->mediaImage)); ?>"
                                                                         class="img-thumbnail">
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td><?php echo e($mediaList->mediaTitle); ?></td>
                                                        <td><?php echo e($mediaList->mediaBy); ?></td>
                                                        <td><?php echo e($mediaList->created_at); ?></td>
                                                        <td><?php echo e(Str::limit(Strip_tags($mediaList->mediaBody),40)); ?></td>
                                                        <td>
                                                            <div class="row-cols-auto">

                                                                <div class="col-sm-2">

                                                                        <a href="<?php echo e(route('admin.media.edit', $mediaList->id)); ?>" class="btn btn-primary"><?php echo e('Edit'); ?></a>

                                                                </div>
                                                                <?php echo "&nbsp;"; ?>

                                                                <div class="col-sm-2">
                                                                    <form action="<?php echo e(route('admin.media.delete', $mediaList->id)); ?>" method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <input type="submit" name="submit" value="Delete" class="btn btn-danger">
                                                                    </form>
                                                                </div>

                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Portfolio-app\resources\views/pages/mediaList.blade.php ENDPATH**/ ?>