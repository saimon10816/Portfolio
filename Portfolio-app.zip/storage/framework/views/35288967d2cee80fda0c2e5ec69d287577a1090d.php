<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">List of Books</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">List of Books</li>
            </ol>
            <div id="layoutSidenav_content">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-50">
                            <div class="card">
                                <div class="card-header"><?php echo e(__('Edit Contents')); ?></div>

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table align-middle">
                                            <thead>
                                            <tr>
                                                <th scope="col">Id</th>
                                                <th scope="col">Award</th>
                                                <th scope="col">Award Title</th>
                                                <th scope="col">Award Description</th>
                                                <th scope="col">Updated At</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php if(count($listAwards) > 0): ?>
                                                <?php $__currentLoopData = $listAwards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listAward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <th scope="row"><?php echo e($listAward->id); ?></th>
                                                        <td>
                                                            <div class="form-group col-md-3 mt-3">
                                                                <div class="mb-4">
                                                                    <img src="<?php echo e(url($listAward->award)); ?>"
                                                                         class="img-thumbnail">
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="mb-7">
                                                                <p class="p-heading"><?php echo e($listAward->awardTitle); ?></p>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="mb-4">
                                                                <p class="p-heading"><?php echo e($listAward->awardDescription); ?></p>
                                                            </div>
                                                        </td>
                                                        <td><?php echo e($listAward->updated_at); ?></td>
                                                        <td>
                                                            <div class="row-cols-lg-auto">

                                                                <div class="col-sm-2">

                                                                        <a href="<?php echo e(route('admin.award.edit', $listAward->id)); ?>" class="btn btn-primary"><?php echo e('Edit'); ?></a>

                                                                </div>
                                                                <?php echo "&nbsp;"; ?>

                                                                <div class="col-sm-2">
                                                                    <form action="<?php echo e(route('admin.award.delete', $listAward->id)); ?>" method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <input type="submit" name="submit" value="Delete" class="btn btn-danger">
                                                                    </form>
                                                                </div>

                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Portfolio-app\resources\views/pages/listAward.blade.php ENDPATH**/ ?>