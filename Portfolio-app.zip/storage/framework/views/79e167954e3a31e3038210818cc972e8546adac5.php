<!-- ======= Footer ======= -->
<div id="footer" class="text-center">
    <div class="container">
        <div class="socials-media text-center">

            <ul class="list-unstyled">
                <li><a href="#"><i class="bi bi-facebook"></i></a></li>
                <li><a href="#"><i class="bi bi-twitter"></i></a></li>
                <li><a href="#"><i class="bi bi-instagram"></i></a></li>
                <li><a href="#"><i class="bi bi-linkedin"></i></a></li>
            </ul>

        </div>

        <p>&copy; Copyrights BugfixIT. All rights reserved.</p>

        <div class="credits">
            <!--
            All the links in the footer should remain intact.
            You can delete the links only if you purchased the pro version.
            Licensing information: https://bootstrapmade.com/license/
            Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Folio
          -->
            Powered by <a href="https://bugfixitbd.com/">BugfixIT</a>
        </div>

    </div>
</div><!-- End Footer -->
<?php /**PATH C:\xampp\htdocs\Portfolio-app\resources\views/pages/footer.blade.php ENDPATH**/ ?>